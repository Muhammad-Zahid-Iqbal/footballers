import styled from "@mui/material/styles/styled";

const Div = styled('div')({});

export default Div;